require 'yaml'

require 'webfontloader/modules'

module WebFontLoader
  VERSION = '1.6.28'

  ProjectRoot = File.expand_path(File.dirname(__FILE__) + "/..")

end
