/**
 * @type {function(function():*)}
 */
var define;

/**
 * @type {boolean?}
 */
define.amd;

/**
 * @type {Object}
 */
var module;

/**
 * @type {Object?}
 */
module.exports;
